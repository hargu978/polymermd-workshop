# Day 4: Polymer Chain MD Simulation with GROMACS

This tutorial demonstrates how to prepare a solvated polymer system and perform molecular dynamics (MD) simulations using **GROMACS**. The workflow includes energy minimization, NVT equilibration, and NPT equilibration.

---

## Table of Contents

1. [Initialization](#initialization)
2. [System Generation](#system-generation)
   - [Copy Initial Files](#copy-initial-files)
   - [Solvate the Polymer](#solvate-the-polymer)
   - [Add Ions](#add-ions)
3. [Energy Minimization](#energy-minimization)
4. [Equilibration](#equilibration)
   - [NVT Equilibration](#nvt-equilibration)
   - [NPT Equilibration](#npt-equilibration)
5. [Visualization](#visualization)

---

## Initialization

The first step is to set up the environment for the tutorial. This includes:
- Opening the terminal and navigating to the `polymermd-workshop-main` folder:
  ```bash
  cd /PATH_TO/polymermd-workshop-main
  ```
  Replace *PATH_TO* with the directory path on your computer.

- Activating the conda environment:
  ```bash
  conda activate polymer-md
  ```

- Launching Jupyter Lab:
  ```bash
  jupyter lab --ip 0.0.0.0 --no-browser
  ```
  Open the printed URL in your browser, or configure it to open automatically.

- Installing required Python packages:
  ```bash
  pip install nglview parmed pandas panedr MDAnalysis
  ```

---

## System Generation

### Copy Initial Files

Copy the polymer structure (`.gro`) and topology (`.top`) files generated in Day 3 to the current working directory.

```python
polymer_name = "PEO25_PET25_random"
polymer_dir = os.path.join(PROJECT_ROOT, "simulations", polymer_name)
os.makedirs(polymer_dir, exist_ok=True)
os.chdir(polymer_dir)

# Copy necessary files
copy_gro = f"cp ../../../Day3-gen-polymer-solved/polymers/{polymer_name}/polymer*gro polymer.gro"
copy_top = f"cp ../../../Day3-gen-polymer-solved/polymers/{polymer_name}/topol.top topol.top"
run_command(copy_gro)
run_command(copy_top)
```

### Solvate the Polymer

Add a cubic water box around the polymer and solvate the system with SPC/E water molecules.

```python
editconf_cmd = "gmx editconf -f polymer.gro -o polymer_box.gro -d 1.0 -bt cubic"
run_command(editconf_cmd)

solvate_cmd = "gmx solvate -cp polymer_box.gro -cs spc216.gro -o polymer_solv.gro -p topol.top -maxsol 1000"
run_command(solvate_cmd)
```

### Add Ions

Neutralize the system and add Na+ and Cl- ions to achieve a concentration of 0.01 M.

```python
grompp_cmd = "gmx grompp -f minimization.mdp -c polymer_solv.gro -p topol.top -o ions.tpr"
run_command(grompp_cmd)

genion_cmd = "echo SOL | gmx genion -s ions.tpr -o polymer_solv_ions.gro -p topol.top -pname NA -nname CL -neutral -conc 0.01"
run_command(genion_cmd)
```

---

## Energy Minimization

Perform energy minimization to remove steric clashes and optimize the system geometry.

```python
em_dir = os.path.join(PROJECT_ROOT, "simulations", polymer_name, "em")
os.makedirs(em_dir, exist_ok=True)
os.chdir(em_dir)

# Write energy minimization parameters
with open("em.mdp", "w") as f:
    f.write("""
integrator  = steep
emtol       = 10.0
emstep      = 0.01
nsteps      = 100000
nstlist     = 1
ns_type     = grid
rlist       = 1.3
rcoulomb    = 1.3
rvdw        = 1.3
pbc         = xyz
""")

# Generate .tpr file and run minimization
grompp_cmd = "gmx grompp -f em.mdp -c ../polymer_solv_ions.gro -p ../topol.top -o em.tpr -maxwarn 2"
run_command(grompp_cmd)

mdrun_cmd = "gmx mdrun -s em.tpr -deffnm em -v"
print(f"Run the following command in the terminal to start energy minimization:\n{mdrun_cmd}")
run_command(mdrun_cmd)
```

---

## Equilibration

### NVT Equilibration

Stabilize the system at constant number of particles (N), volume (V), and temperature (T).

```python
nvt_dir = os.path.join(PROJECT_ROOT, "simulations", polymer_name, "nvt")
os.makedirs(nvt_dir, exist_ok=True)
os.chdir(nvt_dir)

# Write NVT equilibration parameters
with open("nvt.mdp", "w") as f:
    f.write("""
integrator              = md
nsteps                  = 50000
dt                      = 0.002
tcoupl                  = V-rescale
tc-grps                 = System
tau_t                   = 0.1
ref_t                   = 300
pcoupl                  = no
gen_vel                 = yes
gen_temp                = 300
""")

# Generate .tpr file and run NVT equilibration
grompp_cmd = "gmx grompp -f nvt.mdp -c ../em/em.gro -p ../topol.top -o nvt.tpr -maxwarn 2"
run_command(grompp_cmd)

mdrun_cmd = "gmx mdrun -s nvt.tpr -deffnm nvt -v"
print(f"Run the following command in the terminal to start NVT equilibration:\n{mdrun_cmd}")
run_command(mdrun_cmd)
```

### NPT Equilibration

Stabilize the system at constant pressure (1 bar) and temperature (300 K).

```python
npt_dir = os.path.join(PROJECT_ROOT, "simulations", polymer_name, "npt")
os.makedirs(npt_dir, exist_ok=True)
os.chdir(npt_dir)

# Write NPT equilibration parameters
with open("npt.mdp", "w") as f:
    f.write("""
integrator              = md
nsteps                  = 50000
dt                      = 0.002
tcoupl                  = V-rescale
tc-grps                 = System
tau_t                   = 0.1
ref_t                   = 300
pcoupl                  = Berendsen
pcoupltype              = isotropic
tau_p                   = 2.0
ref_p                   = 1.0
compressibility         = 4.5e-5
""")

# Generate .tpr file and run NPT equilibration
grompp_cmd = "gmx grompp -f npt.mdp -c ../nvt/nvt.gro -p ../topol.top -o npt.tpr -maxwarn 2"
run_command(grompp_cmd)

mdrun_cmd = "gmx mdrun -s npt.tpr -deffnm npt -v"
print(f"Run the following command in the terminal to start NPT equilibration:\n{mdrun_cmd}")
run_command(mdrun_cmd)
```

---

## Visualization

Visualize the polymer structure or trajectory using **nglview**.

```python
visualize_trajectory("polymer_solv_ions.gro")
```

--- 

## License

This tutorial is provided under the MIT License. Use it freely for educational and research purposes.
